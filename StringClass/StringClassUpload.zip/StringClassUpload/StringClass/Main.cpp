#include <algorithm>
#include <iostream>
#include <string>
#include <fstream>
#include "Def.h"

using namespace std;

int main()
{
	Custom_String apple;

//	apple.test_CharacterAt();
//
//	apple.test_EqualTo();
//
//
//	apple.test_Prepend();
//
//	apple.test_ToLower();
//
//	apple.test_ToUpper();
//
//	apple.test_Find();
//
//	apple.test_Find();
//
//	apple.test_ReadFromConsole();
//
//	apple.test_WriteToConsole();

	apple.test_All();
}